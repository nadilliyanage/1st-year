<?php
include "db_conn.php";

if (isset($_POST["submit"])) {
   $first_name = $_POST['first_name'];
   $last_name = $_POST['last_name'];
   $email = $_POST['email'];
   $password = $_POST['password'];
   $nic = $_POST['nic'];
   $module1 = $_POST['module1'];
   $module2 = $_POST['module2'];
   $module3 = $_POST['module3'];
   $bank = $_POST['bank'];
   $account=$_POST['account'];
   $accname=$_POST['accname'];
   
   $sql = "INSERT INTO lecturer(id, first_name, last_name, email, password, nic, module1, module2, module3, bank, account, accname ) VALUES (NULL,'$first_name','$last_name','$email','$password','$nic', '$module1', '$module2', '$module3', '$bank', '$account', '$accname')";

   $result = mysqli_query($conn, $sql);

   if ($result) {
      header("Location: index-lecturer.php?msg=New record created successfully");
   } else {
      echo "Failed: " . mysqli_error($conn);
   }
}

?>




<!DOCTYPE html>
<html lang="en">

<head>
	<link rel="stylesheet" type="text/css" href="styles/style.css">
	<link rel="stylesheet" type="text/css" href="styles/sign up lecturer.css">
  
   <title>Sign up Lecturer</title>
</head>

<body>
  <header>
    <div class="logo">
      <img src="images/logo.png" alt="" height="40" width="130">
    </div>
    <nav>
      <ul>
        <li><a href="add-contactus.php">Contact US</a></li>
        <li><a href="Help & support.html">Help & Support</a></li>
      </ul>
    </nav>
  </header>

   <br>
         <h3>Sign up Lecturer</h3>
         <p>Complete the form below to Sign up</p>
    
	
      <div class="container">
         <form action="" method="post" style="width:50vw; min-width:300px;">
            <div class="row mb-3">
               <div class="col">
                  <label class="form-label">First Name:</label>
                  <input type="text"  name="first_name" placeholder="Albert" required>
               </div>

               <div class="col">
                  <label class="form-label">Last Name:</label>
                  <input type="text"  name="last_name" placeholder="Einstein" required>
               </div>
            </div>

            <div class="mb-3">
               <label class="form-label">Email:</label>
               <input type="email"  name="email" placeholder="name@example.com" required>
            </div>

            <label for="password">Password:</label><br>
      <input type="password" id="password" name="password" id="password" placeholder="Abc@123" required >
      <input type="checkbox" onclick="myFunction()">Show Password

<script>
function myFunction() {
  var x = document.getElementById("password");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}
</script>
      <br>
      <label for="nic">NIC:</label><br>
      <input type="text" id="nic" name="nic" maxlength="12" placeholder="200216601045 / 6954784125V" required>
      <br>
	  

  
      <label for="module1">Select First Module:</label><br>
      <select id="module1" name="module1" required>
	   <option value="Not Selected">Select Module:</option>
      <option value="Introduction to Pedagogy">Introduction to Pedagogy</option>
		<option value="Effective Lesson Planning">Effective Lesson Planning</option>
		<option value="Classroom Management Strategies">Classroom Management Strategies</option>
		<option value="Assessment Techniques">Assessment Techniques</option>
		<option value="Introduction to Educational Technology">Introduction to Educational Technology</option>
		<option value="Digital Literacy and Citizenship">Digital Literacy and Citizenship</option>
		<option value="Online Tools for Teaching">Online Tools for Teaching</option>
		<option value="Instructional Technology in the Classroom">Instructional Technology in the Classroom</option>
		<option value="Introduction to Differentiated Instruction">Introduction to Differentiated Instruction</option>
		<option value="Understanding Learning Styles">Understanding Learning Styles</option>
		<option value="Accommodations for Diverse Learners">Accommodations for Diverse Learners</option>
		<option value="Strategies for Differentiating Instruction">Strategies for Differentiating Instruction</option>
		<option value="Introduction to Special Education">Introduction to Special Education</option>
		<option value="Laws and Regulations in Special Education">Laws and Regulations in Special Education</option>
		<option value="Understanding IEPs">Understanding IEPs</option>
		<option value="Strategies for Supporting Students with">Strategies for Supporting Students with</option>
		<option value="Disabilities">Disabilities</option>
		<option value="Introduction to Culturally Responsive Teaching">Introduction to Culturally Responsive Teaching</option>
		<option value="Cultural Competence and Awareness">Cultural Competence and Awareness</option>
		<option value="Anti-Bias Education">Anti-Bias Education</option>
		<option value="Strategies for Culturally Responsive Teaching">Strategies for Culturally Responsive Teaching</option>

      </select><br>
	  
	  <label for="module2">Select Second Module:</label><br>
      <select id="module2" name="module2">
	   <option value="Not Selected">Select Module:</option>
      <option value="Introduction to Pedagogy">Introduction to Pedagogy</option>
		<option value="Effective Lesson Planning">Effective Lesson Planning</option>
		<option value="Classroom Management Strategies">Classroom Management Strategies</option>
		<option value="Assessment Techniques">Assessment Techniques</option>
		<option value="Introduction to Educational Technology">Introduction to Educational Technology</option>
		<option value="Digital Literacy and Citizenship">Digital Literacy and Citizenship</option>
		<option value="Online Tools for Teaching">Online Tools for Teaching</option>
		<option value="Instructional Technology in the Classroom">Instructional Technology in the Classroom</option>
		<option value="Introduction to Differentiated Instruction">Introduction to Differentiated Instruction</option>
		<option value="Understanding Learning Styles">Understanding Learning Styles</option>
		<option value="Accommodations for Diverse Learners">Accommodations for Diverse Learners</option>
		<option value="Strategies for Differentiating Instruction">Strategies for Differentiating Instruction</option>
		<option value="Introduction to Special Education">Introduction to Special Education</option>
		<option value="Laws and Regulations in Special Education">Laws and Regulations in Special Education</option>
		<option value="Understanding IEPs">Understanding IEPs</option>
		<option value="Strategies for Supporting Students with">Strategies for Supporting Students with</option>
		<option value="Disabilities">Disabilities</option>
		<option value="Introduction to Culturally Responsive Teaching">Introduction to Culturally Responsive Teaching</option>
		<option value="Cultural Competence and Awareness">Cultural Competence and Awareness</option>
		<option value="Anti-Bias Education">Anti-Bias Education</option>
		<option value="Strategies for Culturally Responsive Teaching">Strategies for Culturally Responsive Teaching</option>

      </select><br>
	  
	  <label for="module3">Select Third Module:</label><br>
      <select id="module3" name="module3">
      <option value="Not Selected">Select Module:</option>
      <option value="Introduction to Pedagogy">Introduction to Pedagogy</option>
		<option value="Effective Lesson Planning">Effective Lesson Planning</option>
		<option value="Classroom Management Strategies">Classroom Management Strategies</option>
		<option value="Assessment Techniques">Assessment Techniques</option>
		<option value="Introduction to Educational Technology">Introduction to Educational Technology</option>
		<option value="Digital Literacy and Citizenship">Digital Literacy and Citizenship</option>
		<option value="Online Tools for Teaching">Online Tools for Teaching</option>
		<option value="Instructional Technology in the Classroom">Instructional Technology in the Classroom</option>
		<option value="Introduction to Differentiated Instruction">Introduction to Differentiated Instruction</option>
		<option value="Understanding Learning Styles">Understanding Learning Styles</option>
		<option value="Accommodations for Diverse Learners">Accommodations for Diverse Learners</option>
		<option value="Strategies for Differentiating Instruction">Strategies for Differentiating Instruction</option>
		<option value="Introduction to Special Education">Introduction to Special Education</option>
		<option value="Laws and Regulations in Special Education">Laws and Regulations in Special Education</option>
		<option value="Understanding IEPs">Understanding IEPs</option>
		<option value="Strategies for Supporting Students with">Strategies for Supporting Students with</option>
		<option value="Disabilities">Disabilities</option>
		<option value="Introduction to Culturally Responsive Teaching">Introduction to Culturally Responsive Teaching</option>
		<option value="Cultural Competence and Awareness">Cultural Competence and Awareness</option>
		<option value="Anti-Bias Education">Anti-Bias Education</option>
		<option value="Strategies for Culturally Responsive Teaching">Strategies for Culturally Responsive Teaching</option>


      </select><br>

      <label for="courses">About Modules <a href="About Course.html">click here.</a></label>
      <br><br>

      <h2>Bank Details</h2>

      <br>
	  
	  <label for="bank">Choose the Bank:</label><br>
      <select id="bank" name="bank">
      <option value="Bank of Ceylon (BOC)">Bank of Ceylon (BOC)</option>
      <option value="People's Bank">People's Bank</option>
      <option value="Commercial Bank of Ceylon">Commercial Bank of Ceylon</option>
		<option value="Hatton National Bank (HNB)">Hatton National Bank (HNB)</option>
		<option value="Sampath Bank">Sampath Bank</option>
		<option value="National Savings Bank (NSB)">National Savings Bank (NSB)</option>
		<option value="Seylan Bank">Seylan Bank</option>
		<option value="DFCC Bank">DFCC Bank</option>
      </select>

      <br>
      <label for="account">Account Number:</label><br>
      <input type="text" id="account" name="account" required>
      <br>
      <label for="accname">Account Name:</label><br>
      <input type="text" id="accname" name="accname" required>
      <br>
      

      <input type="checkbox" id="agree" name="agree" required>
      <label for="agree">I agree to the <a href="terms and conditions.html">Terms and Conditions.</a></label>
      <br>

            <div>
               <button type="submit" class="btn btn-success" name="submit">Submit</button>
               <a href="Sign up cover.html" class="cancel">Cancel</a>
            </div>
         </form>
      </div>
   </div>

  
   <footer class="footer-section">
	<hr style="color:white;">
	<div class="sup_img">
	  <img src="images/support.png" alt="" height="150" width="200"><br>
      <h3>DO YOU NEED ANY</h3>
	  <h1>SUPPORT?</h1>
	</div>

  <div class="footer-cta pt-5 pb-5">
    <div class="single-cta">
      <div class="cta-text">
        <img src="images/location.png" alt="" height="35" width="35">
        <h4>Find us</h4>
        <span>105, New Kandy RD, Malabe</span>
      </div>
	  
	  <div class="calendar"></div>

	  
    </div>
    <div class="single-cta">
      <div class="cta-text">
        <img src="images/Phone.png" alt="" height="35" width="35">
        <h4>Call us</h4>
        <span>+94 71 234 5678</span>
      </div>
    </div>
    <div class="single-cta">
      <div class="cta-text">
        <img src="images/mail.png" alt="" height="35" width="35">
        <h4>Mail us</h4>
        <span>info@eduteach.com</span>
      </div>
	  <div class="download">
	    <p><b>Get us on</b></p>
	    <img src="images/playstore.png" alt="" height="40" width="80">
        <img src="images/appstore.png" alt="" height="40" width="80">
        <img src="images/winstore.png" alt="" height="40" width="80">
	  </div>
    </div>
  </div>
  <div class="social_logo">
    <a href="https://support.google.com/accounts/answer/27441?hl=en"><img src="images/google.png" alt="" height="20" width="20"></a>
    <a href="https://www.linkedin.com/signup"><img src="images/linkedin.png" alt="" height="20" width="20"></a>
    <a href="https://twitter.com/i/flow/signup"><img src="images/twitter.png" alt="" height="20" width="20"></a>
    <a href="https://www.facebook.com/signup"><img src="images/fb.png" alt="" height="20" width="20"></a>
    <a href="https://web.telegram.org/"><img src="images/telegram.png" alt="" height="20" width="20"></a>
    <a href="https://github.com/signup"><img src="images/github.png" alt="" height="20" width="20"></a>
  </div>
  
<div class="copyright">
<p>Visit Our Page : <a href="Login-index.php">https://www.eduteach.com</a></p>
  
</div>
  <h6>Created By MLB_11.1_09<h6>
  <script src="js/calendar.js"></script>
</footer>
</body>

</html>