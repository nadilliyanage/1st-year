<!DOCTYPE html>
<html>
  <head>
    <title>Payment</title>
    <link rel="stylesheet" href="styles/payment.css">
    <link rel="stylesheet" href="styles/style.css">

  </head>
  <body>

  <header>
  <div class="logo">
    <img src="images/logo.png" alt="" height="40" width="130">
  </div>
  <nav>
    <ul>
      <li><a href="Home.php">Home</a></li>
      <li><a href="course.html">My Course</a></li>
      <li><a href="add-contactus.php">Contact US</a></li>
      <li><a href="Help & support.html">Help & Support</a></li>
    </ul>
  </nav>
</header>
<hr style="color:white;">
    <div class="bg">
   

  
    <div class="container">
      <div class="main-content">

      </div>
  
    
  <form action="payment.php" method="POST">
    
      <div class="card-details">
       
        <div class="card-type">
            <label> Card Type </label><br>
            <input type="radio" id="visa" name="type" value="visa" required>
            <label for="visa"><img class="visa" src="images/visa.jpg"></label>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <input type="radio" id="mastercard" name="type" value="mastercard">
            <label for="visa"><img class="mastercard" src="images/mastercard.jpg"></label>
        </div>
        <br>
        <div class="card-number">
          <label> Card Number: </label>
          <input type="text" id="cnumber" name="cnumber" class="card-number-field" placeholder="###-###-###">
        </div>

        <div class="nameholder-number">
            <label> Card Holder name: </label>
            <input type="text" id="holdername" name="holdername" class="card-name-field" placeholder="Enter your Name">
          </div>

        <div class="date-number">
          <label> Expiry Date: </label>
          <input type="text" id="exp" name="exp" class="date-number-field" placeholder="MM-YY">
        </div>
  
        <div class="cvv-number">
          <label>CVV Number:</label>
          <input type="text" id="cvv" name="cvv" class="cvv-number-field" 
                 placeholder="xxx" />
        </div>
        <div class="amount">
          <label>Amount:</label>
          <input type="text" id="amount" name="amount" class="amount-field" 
                 placeholder="0.00" />
        </div>

        <br><br><br>
        
        <button type="submit" name="submit" class="submit-now-btn">PAY</button>

      </div>
</form> 
    </div>
  
    <footer class="footer-section">
	<hr style="color:white;">
	<div class="sup_img">
	  <img src="images/support.png" alt="" height="150" width="200"><br>
      <h3>DO YOU NEED ANY</h3>
	  <h1>SUPPORT?</h1>
	</div>

  <div class="footer-cta pt-5 pb-5">
    <div class="single-cta">
      <div class="cta-text">
        <img src="images/location.png" alt="" height="35" width="35">
        <h4>Find us</h4>
        <span>105, New Kandy RD, Malabe</span>
      </div>
	  
	  <div class="calendar"></div>

	  
    </div>
    <div class="single-cta">
      <div class="cta-text">
        <img src="images/Phone.png" alt="" height="35" width="35">
        <h4>Call us</h4>
        <span>+94 71 234 5678</span>
      </div>
    </div>
    <div class="single-cta">
      <div class="cta-text">
        <img src="images/mail.png" alt="" height="35" width="35">
        <h4>Mail us</h4>
        <span>info@eduteach.com</span>
      </div>
	  <div class="download">
	    <p><b>Get us on</b></p>
	    <img src="images/playstore.png" alt="" height="40" width="80">
        <img src="images/appstore.png" alt="" height="40" width="80">
        <img src="images/winstore.png" alt="" height="40" width="80">
	  </div>
    </div>
  </div>
  <div class="social_logo">
    <a href="https://support.google.com/accounts/answer/27441?hl=en"><img src="images/google.png" alt="" height="20" width="20"></a>
    <a href="https://www.linkedin.com/signup"><img src="images/linkedin.png" alt="" height="20" width="20"></a>
    <a href="https://twitter.com/i/flow/signup"><img src="images/twitter.png" alt="" height="20" width="20"></a>
    <a href="https://www.facebook.com/signup"><img src="images/fb.png" alt="" height="20" width="20"></a>
    <a href="https://web.telegram.org/"><img src="images/telegram.png" alt="" height="20" width="20"></a>
    <a href="https://github.com/signup"><img src="images/github.png" alt="" height="20" width="20"></a>
  </div>
  
<div class="copyright">
  <p>Visit Our Page : <a href="Login-index.php">https://www.eduteach.com</a></p>
  
</div>
  <h6>Created By MLB_11.1_09<h6>
  <script src="js/calendar.js"></script>
</footer>
 
  </body>
</html>