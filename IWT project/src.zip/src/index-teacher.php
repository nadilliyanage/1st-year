<?php
include "db_conn.php";
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <link rel="stylesheet" type="text/css" href="styles/style.css">
	<link rel="stylesheet" type="text/css" href="styles/sign up teacher.css">
  <title>Sign up Trainer Teacher</title>
</head>

<body>
<header>
    <div class="logo">
      <img src="images/logo.png" alt="" height="40" width="130">
    </div>
    <nav>
      <ul>
        <li><a href="add-contactus.php">Contact US</a></li>
        <li><a href="Help & support.html">Help & Support</a></li>
      </ul>
    </nav>
  </header>

  <div class="container">
  <?php
    if (isset($_GET["msg"])) {
      $msg = $_GET["msg"];
      echo '<div class="alert" role="alert">' . $msg . '</div><br><br>';
  }
    ?>
    <a href="add-new-teacher.php" class="add-new">Add New</a>

    <table class="table-viwe">
      <thead class="table-dark">
        <tr>
          
          <th scope="col">First Name</th>
          <th scope="col">Last Name</th>
          <th scope="col">Email</th>
          <th scope="col">Password</th>
          <th scope="col">Nic</th>
          <th scope="col">Course</th>
          <th scope="col">Action</th>
        </tr>
      </thead>
      <tbody>
        <?php
        $sql = "SELECT * FROM `teacher`";
        $result = mysqli_query($conn, $sql);
        while ($row = mysqli_fetch_assoc($result)) {
        ?>
          <tr>
            
            <td><?php echo $row["first_name"] ?></td>
            <td><?php echo $row["last_name"] ?></td>
            <td><?php echo $row["email"] ?></td>
            <td><?php echo $row["password"]?></td>
            <td><?php echo $row["nic"] ?></td>
            <td><?php echo $row["course"] ?></td>
            <td>
              <a href="edit-teacher.php?id=<?php echo $row["id"] ?>" class="edit-button">Update</a><br>
              <a href="delete-teacher.php?id=<?php echo $row["id"] ?>" class="delete-button">Delete </a>
            </td>
          </tr>
        <?php
        }
        ?>
      </tbody>
    </table>
    <a href="login-index.php"><button class="log">Go to Log In</button></a>
  </div>


  <footer class="footer-section">
	<hr style="color:white;">
	<div class="sup_img">
	  <img src="images/support.png" alt="" height="150" width="200"><br>
      <h3>DO YOU NEED ANY</h3>
	  <h1>SUPPORT?</h1>
	</div>

  <div class="footer-cta pt-5 pb-5">
    <div class="single-cta">
      <div class="cta-text">
        <img src="images/location.png" alt="" height="35" width="35">
        <h4>Find us</h4>
        <span>105, New Kandy RD, Malabe</span>
      </div>
	  
	  <div class="calendar"></div>

	  
    </div>
    <div class="single-cta">
      <div class="cta-text">
        <img src="images/Phone.png" alt="" height="35" width="35">
        <h4>Call us</h4>
        <span>+94 71 234 5678</span>
      </div>
    </div>
    <div class="single-cta">
      <div class="cta-text">
        <img src="images/mail.png" alt="" height="35" width="35">
        <h4>Mail us</h4>
        <span>info@eduteach.com</span>
      </div>
	  <div class="download">
	    <p><b>Get us on</b></p>
	    <img src="images/playstore.png" alt="" height="40" width="80">
        <img src="images/appstore.png" alt="" height="40" width="80">
        <img src="images/winstore.png" alt="" height="40" width="80">
	  </div>
    </div>
  </div>
  <div class="social_logo">
    <a href="https://support.google.com/accounts/answer/27441?hl=en"><img src="images/google.png" alt="" height="20" width="20"></a>
    <a href="https://www.linkedin.com/signup"><img src="images/linkedin.png" alt="" height="20" width="20"></a>
    <a href="https://twitter.com/i/flow/signup"><img src="images/twitter.png" alt="" height="20" width="20"></a>
    <a href="https://www.facebook.com/signup"><img src="images/fb.png" alt="" height="20" width="20"></a>
    <a href="https://web.telegram.org/"><img src="images/telegram.png" alt="" height="20" width="20"></a>
    <a href="https://github.com/signup"><img src="images/github.png" alt="" height="20" width="20"></a>
  </div>
  
<div class="copyright">
<p>Visit Our Page : <a href="Login-index.php">https://www.eduteach.com</a></p>
  
</div>
  <h6>Created By MLB_11.1_09<h6>
  <script src="js/calendar.js"></script>
</footer>
  
</body>

</html>

