<?php
include "db_conn.php";
$id = $_GET["id"];

if (isset($_POST["submit"])) {
   $date = $_POST['date'];
   $time = $_POST['time'];
   $subject = $_POST['subject'];
   
   $sql = "UPDATE `exam` SET `date`='$date', `time`='$time', `subject`='$subject' WHERE id = $id";

  $result = mysqli_query($conn, $sql);

  if ($result) {
    header("Location: home.php?msg=Data updated successfully");
  } else {
    echo "Failed: " . mysqli_error($conn);
  }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
  
	<link rel="stylesheet" type="text/css" href="styles/style.css">
	<link rel="stylesheet" type="text/css" href="styles/form.css">
  
   <title>Exam</title>
</head>

<body>
  <header>
    <div class="logo">
      <img src="images/logo.png" alt="" height="40" width="130">
    </div>
    <nav>
      <ul>
        <li><a href="add-contactus.php">Contact US</a></li>
        <li><a href="Help & support.html">Help & Support</a></li>
      </ul>
    </nav>
  </header>

  <br>
  <h3>Edit Exam</h3>

  <?php
  $sql = "SELECT * FROM `exam` WHERE id = $id LIMIT 1";
  $result = mysqli_query($conn, $sql);
  $row = mysqli_fetch_assoc($result);
  ?>

  <div class="container">
    <form action="" method="post" style="width:50vw; min-width:300px;">
      <label for="date">Date:</label><br>
      <input type="text" id="date" name="date" value="<?php echo $row['date']; ?>" placeholder="YYYY-MM-DD" required><br>

      <label for="time">Time:</label><br>
      <input type="text" id="time" name="time" value="<?php echo $row['time']; ?>" placeholder="hh:mm:ss" required><br>

      <label for="subject">Subject:</label><br>
      <input type="text" id="subject" name="subject" value="<?php echo $row['subject']; ?>" placeholder="IWT" required><br>

      <div>
        <button type="submit" class="btn btn-success" name="submit">Submit</button>
        <a href="Home.php" class="cancel">Cancel</a>
      </div>
    </form>
  </div>

  <footer class="footer-section">
   
  </footer>
</body>

</html>
