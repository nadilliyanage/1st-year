<?php
include "db_conn.php";
$id = $_GET["id"];

if (isset($_POST["submit"])) {
   $module = $_POST['module'];
   $duration = $_POST['duration'];
   $lecId = $_POST['lecId'];
   $link=$_POST['link'];
   $sql = "UPDATE `timetable-PCM` SET `module`='$module',`duration`='$duration',`lecId`='$lecId',`link`='$link' WHERE id = $id";

  $result = mysqli_query($conn, $sql);

  if ($result) {
    header("Location: pcm.php?msg=Data updated successfully");
  } else {
    echo "Failed: " . mysqli_error($conn);
  }
}

?>



<!DOCTYPE html>
<html lang="en">

<head>
  
	<link rel="stylesheet" type="text/css" href="styles/style.css">
	<link rel="stylesheet" type="text/css" href="styles/form.css">
  
   <title>time table</title>
</head>

<body>
<header>
  <div class="logo">
    <img src="images/logo.png" alt="" height="40" width="130">
  </div>
  <nav>
    <ul>
      <li><a href="Home.php">Home</a></li>
      <li><a href="course.html">My Course</a></li>
      <li><a href="add-contactus.php">Contact US</a></li>
      <li><a href="Help & support.html">Help & Support</a></li>
    </ul>
  </nav>
</header>
<hr style="color:white;">

   <br>
         <h3>Change Lecture</h3>

         <?php
           $sql = "SELECT * FROM `timetable-PCM` WHERE id = $id LIMIT 1";
          $result = mysqli_query($conn, $sql);
          $row = mysqli_fetch_assoc($result);
        ?>
    
      <div class="container">
         <form action="" method="post" style="width:50vw; min-width:300px;">
      
        <label for="module"> Module:</label><br>
      <select id="module" name="module" required>
	   <option value="Not Selected">Select Module:</option>
      <option value="Introduction to Pedagogy" <?php if ($row['module'] == "Introduction to Pedagogy") echo "selected"; ?>>Introduction to Pedagogy</option>
		<option value="Effective Lesson Planning" <?php if ($row['module'] == "Effective Lesson Planning") echo "selected"; ?>>Effective Lesson Planning</option>
		<option value="Classroom Management Strategies" <?php if ($row['module'] == "Classroom Management Strategies") echo "selected"; ?>>Classroom Management Strategies</option>
		<option value="Assessment Techniques" <?php if ($row['module'] == "Assessment Techniques") echo "selected"; ?>>Assessment Techniques</option>
		

      </select><br>

      <<label for="duration">Duration:</label><br>
      <input type="text" id="duration" name="duration" value="<?php echo $row['duration']; ?>" placeholder="1 hour 30 min" required>
      <br>
      <label for="lecId">Lec Id:</label><br>
      <input type="text" id="lecId" name="lecId" value="<?php echo $row['lecId']; ?>" placeholder="TT0000" required>
      <br>   
      
      <label for="link">Link:</label><br>
      <input type="text" id="link" name="link" value="<?php echo $row['link']; ?>"  placeholder="add link" required>
      <br>
        

      
	  
            <div>
               <button type="submit" class="btn btn-success" name="submit">Submit</button>
               <a href="PCM.php" class="cancel">Cancel</a>
            </div>
         </form>

        
      </div>
   </div>

   
   <footer class="footer-section">
	<hr style="color:white;">
	<div class="sup_img">
	  <img src="images/support.png" alt="" height="150" width="200"><br>
      <h3>DO YOU NEED ANY</h3>
	  <h1>SUPPORT?</h1>
	</div>

  <div class="footer-cta pt-5 pb-5">
    <div class="single-cta">
      <div class="cta-text">
        <img src="images/location.png" alt="" height="35" width="35">
        <h4>Find us</h4>
        <span>105, New Kandy RD, Malabe</span>
      </div>
	  
	  <div class="calendar"></div>

	  
    </div>
    <div class="single-cta">
      <div class="cta-text">
        <img src="images/Phone.png" alt="" height="35" width="35">
        <h4>Call us</h4>
        <span>+94 71 234 5678</span>
      </div>
    </div>
    <div class="single-cta">
      <div class="cta-text">
        <img src="images/mail.png" alt="" height="35" width="35">
        <h4>Mail us</h4>
        <span>info@eduteach.com</span>
      </div>
	  <div class="download">
	    <p><b>Get us on</b></p>
	    <img src="images/playstore.png" alt="" height="40" width="80">
        <img src="images/appstore.png" alt="" height="40" width="80">
        <img src="images/winstore.png" alt="" height="40" width="80">
	  </div>
    </div>
  </div>
  <div class="social_logo">
    <a href="https://support.google.com/accounts/answer/27441?hl=en"><img src="images/google.png" alt="" height="20" width="20"></a>
    <a href="https://www.linkedin.com/signup"><img src="images/linkedin.png" alt="" height="20" width="20"></a>
    <a href="https://twitter.com/i/flow/signup"><img src="images/twitter.png" alt="" height="20" width="20"></a>
    <a href="https://www.facebook.com/signup"><img src="images/fb.png" alt="" height="20" width="20"></a>
    <a href="https://web.telegram.org/"><img src="images/telegram.png" alt="" height="20" width="20"></a>
    <a href="https://github.com/signup"><img src="images/github.png" alt="" height="20" width="20"></a>
  </div>
  
<div class="copyright">
<p>Visit Our Page : <a href="Login-index.php">https://www.eduteach.com</a></p>
  
</div>
  <h6>Created By MLB_11.1_09<h6>
  <script src="js/calendar.js"></script>
</footer>
</body>

</html>