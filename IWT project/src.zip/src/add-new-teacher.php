<?php
include "db_conn.php";

if (isset($_POST["submit"])) {
   $first_name = $_POST['first_name'];
   $last_name = $_POST['last_name'];
   $email = $_POST['email'];
   $password = $_POST['password'];
   $nic = $_POST['nic'];
   $course = $_POST['course'];

   $sql= "INSERT INTO teacher(id, first_name, last_name, email, password, nic, course ) VALUES (NULL,'$first_name','$last_name','$email','$password','$nic', '$course')";

   $result = mysqli_query($conn, $sql);

   if ($result) {
      header("Location: index-teacher.php?msg=New record created successfully");
   } else {
      echo "Failed: " . mysqli_error($conn);
   }
}

?>




<!DOCTYPE html>
<html lang="en">

<head>
  
	<link rel="stylesheet" type="text/css" href="styles/style.css">
	<link rel="stylesheet" type="text/css" href="styles/sign up teacher.css">
  
   <title>Sign up Lecturer</title>
</head>

<body>
  <header>
    <div class="logo">
      <img src="images/logo.png" alt="" height="40" width="130">
    </div>
    <nav>
      <ul>
        <li><a href="add-contactus.php">Contact US</a></li>
        <li><a href="Help & support.html">Help & Support</a></li>
      </ul>
    </nav>
  </header>

   <br>
         <h3>Sign up Trainer Teacher</h3>
         <p>Complete the form below to Sign up</p>
    
	
      <div class="container">
         <form action="" method="post" style="width:50vw; min-width:300px;">
            <div class="row mb-3">
               <div class="col">
                  <label class="form-label">First Name:</label>
                  <input type="text"  name="first_name" placeholder="Albert" required>
               </div>

               <div class="col">
                  <label class="form-label">Last Name:</label>
                  <input type="text"  name="last_name" placeholder="Einstein" required>
               </div>
            </div>

            <div class="mb-3">
               <label class="form-label">Email:</label>
               <input type="email"  name="email" placeholder="name@example.com" required>
            </div>

            <label for="password">Password:</label><br>
      <input type="password" id="password" name="password" id="password" placeholder="Abc@123" required >
      <input type="checkbox" onclick="myFunction()">Show Password

<script>
function myFunction() {
  var x = document.getElementById("password");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}
</script>
      <br>
      <label for="nic">NIC:</label><br>
      <input type="text" id="nic" name="nic" maxlength="12" placeholder="200216601045 / 6954784125V" required>
      <br>
	  <br>
      <label for="course">Select Course:</label><br>
      <select id="course" name="course">
        <option value="Pedagogy and Classroom Management">Pedagogy and Classroom Management</option>
        <option value="Technology in Education">Technology in Education</option>
        <option value="Differentiated Instruction">Differentiated Instruction</option>
		<option value="Special Education">Special Education</option>
		<option value="Culturally Responsive Teaching">Culturally Responsive Teaching</option>
      </select>

      <label for="courses">About Courses <a href="About Course.html">click here.</a></label>
      <br><br>

      

      <input type="checkbox" id="agree" name="agree" required>
      <label for="agree">I agree to the <a href="terms and conditions.html">Terms and Conditions.</a></label>
      <br>

            <div>
               <button type="submit" class="btn btn-success" name="submit">Submit</button>
               <a href="Sign up cover.html" class="cancel">Cancel</a>
            </div>
         </form>

         <button class="login-button1" onclick="loginWithFacebook()">Continue with Facebook</button>
         <button class="login-button2" onclick="loginWithgoogle()">Continue with Google</button>
         <button class="login-button3" onclick="loginWithlinkedin()">Continue with LinkedIn</button>
      </div>
   </div>

   
   <footer class="footer-section">
	<hr style="color:white;">
	<div class="sup_img">
	  <img src="images/support.png" alt="" height="150" width="200"><br>
      <h3>DO YOU NEED ANY</h3>
	  <h1>SUPPORT?</h1>
	</div>

  <div class="footer-cta pt-5 pb-5">
    <div class="single-cta">
      <div class="cta-text">
        <img src="images/location.png" alt="" height="35" width="35">
        <h4>Find us</h4>
        <span>105, New Kandy RD, Malabe</span>
      </div>
	  
	  <div class="calendar"></div>

	  
    </div>
    <div class="single-cta">
      <div class="cta-text">
        <img src="images/Phone.png" alt="" height="35" width="35">
        <h4>Call us</h4>
        <span>+94 71 234 5678</span>
      </div>
    </div>
    <div class="single-cta">
      <div class="cta-text">
        <img src="images/mail.png" alt="" height="35" width="35">
        <h4>Mail us</h4>
        <span>info@eduteach.com</span>
      </div>
	  <div class="download">
	    <p><b>Get us on</b></p>
	    <img src="images/playstore.png" alt="" height="40" width="80">
        <img src="images/appstore.png" alt="" height="40" width="80">
        <img src="images/winstore.png" alt="" height="40" width="80">
	  </div>
    </div>
  </div>
  <div class="social_logo">
    <a href="https://support.google.com/accounts/answer/27441?hl=en"><img src="images/google.png" alt="" height="20" width="20"></a>
    <a href="https://www.linkedin.com/signup"><img src="images/linkedin.png" alt="" height="20" width="20"></a>
    <a href="https://twitter.com/i/flow/signup"><img src="images/twitter.png" alt="" height="20" width="20"></a>
    <a href="https://www.facebook.com/signup"><img src="images/fb.png" alt="" height="20" width="20"></a>
    <a href="https://web.telegram.org/"><img src="images/telegram.png" alt="" height="20" width="20"></a>
    <a href="https://github.com/signup"><img src="images/github.png" alt="" height="20" width="20"></a>
  </div>
  
<div class="copyright">
<p>Visit Our Page : <a href="Login-index.php">https://www.eduteach.com</a></p>
  
</div>
  <h6>Created By MLB_11.1_09<h6>
  <script src="js/calendar.js"></script>
</footer>
</body>

</html>