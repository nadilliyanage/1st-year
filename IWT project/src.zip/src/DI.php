<?php
include "db_conn.php";
?>
<!DOCTYPE html>
<html>
<head>
  <title> Differentiated Instruction </title>
  <link rel="stylesheet" type="text/css" href="styles/style.css">
  <link  rel="stylesheet" type="text/css" href="styles/course details.css" > 
  
</head>
<body>
<header>
  <div class="logo">
    <img src="images/logo.png" alt="" height="40" width="130">
  </div>
  <nav>
    <ul>
      <li><a href="Home.php">Home</a></li>
      <li><a href="course.html">My Course</a></li>
      <li><a href="add-contactus.php">Contact US</a></li>
      <li><a href="Help & support.html">Help & Support</a></li>
    </ul>
  </nav>
</header>
<hr style="color:white;">

<h1>Differentiated Instruction</h1>
  <ul class="moduled">
  <li>Module 1:Introduction to Differentiated Instruction</li>
    <li>Module 2: Understanding Learning Styles</li>
    <li>Module 3:Accommodations for Diverse Learners</li>
    <li>Module 4:Strategies for Differentiating Instruction</li>
    
  </ul>

   <br><br>
   <h2>Lecture Timetable</h2>

<div class="container">
<?php
    if (isset($_GET["msg"])) {
      $msg = $_GET["msg"];
      echo '<div class="alert" role="alert">' . $msg . '</div><br><br>';
  }
    ?>
    

    <table class="table-viwe">
      <thead class="table-dark">
        <tr>
          
          <th scope="col">Module</th>
          <th scope="col">Duration</th>
          <th scope="col">Lec Id</th>
          <th scope="col">Link</th>
          <th scope="col">Action</th>

        </tr>
      </thead>
      <tbody>
        <?php
        $sql = "SELECT * FROM `timetable-DI`";
        $result = mysqli_query($conn, $sql);
        while ($row = mysqli_fetch_assoc($result)) {
        ?>
          <tr>
            
            <td><?php echo $row["module"] ?></td>
            <td><?php echo $row["duration"] ?></td>
            <td><?php echo $row["lecId"] ?></td>
            <td><?php echo $row["link"]?></td>

            <td>
              <a href="edit-di.php?id=<?php echo $row["id"] ?>" class="edit-button">Update </a><br>
              <a href="delete-di.php?id=<?php echo $row["id"] ?>" class="delete-button">Delete </a>
            </td>
          </tr>
        <?php
        }
        ?>
      </tbody>
    </table>
    <br><br><br><br>
    <a href="add-timetable-di.php" class="add-new">Add New</a>
  </div>
  <footer class="footer-section">
	<hr style="color:white;">
	<div class="sup_img">
	  <img src="images/support.png" alt="" height="150" width="200"><br>
      <h3>DO YOU NEED ANY</h3>
	  <h1>SUPPORT?</h1>
	</div>

  <div class="footer-cta pt-5 pb-5">
    <div class="single-cta">
      <div class="cta-text">
        <img src="images/location.png" alt="" height="35" width="35">
        <h4>Find us</h4>
        <span>105, New Kandy RD, Malabe</span>
      </div>
	  
	  <div class="calendar"></div>

	  
    </div>
    <div class="single-cta">
      <div class="cta-text">
        <img src="images/Phone.png" alt="" height="35" width="35">
        <h4>Call us</h4>
        <span>+94 71 234 5678</span>
      </div>
    </div>
    <div class="single-cta">
      <div class="cta-text">
        <img src="images/mail.png" alt="" height="35" width="35">
        <h4>Mail us</h4>
        <span>info@eduteach.com</span>
      </div>
	  <div class="download">
	    <p><b>Get us on</b></p>
	    <img src="images/playstore.png" alt="" height="40" width="80">
        <img src="images/appstore.png" alt="" height="40" width="80">
        <img src="images/winstore.png" alt="" height="40" width="80">
	  </div>
    </div>
  </div>
  <div class="social_logo">
    <a href="https://support.google.com/accounts/answer/27441?hl=en"><img src="images/google.png" alt="" height="20" width="20"></a>
    <a href="https://www.linkedin.com/signup"><img src="images/linkedin.png" alt="" height="20" width="20"></a>
    <a href="https://twitter.com/i/flow/signup"><img src="images/twitter.png" alt="" height="20" width="20"></a>
    <a href="https://www.facebook.com/signup"><img src="images/fb.png" alt="" height="20" width="20"></a>
    <a href="https://web.telegram.org/"><img src="images/telegram.png" alt="" height="20" width="20"></a>
    <a href="https://github.com/signup"><img src="images/github.png" alt="" height="20" width="20"></a>
  </div>
  
<div class="copyright">
  <p>Visit Our Page : <a href="Login-index.php">https://www.eduteach.com</a></p>
  
</div>
  <h6>Created By MLB_11.1_09<h6>
  <script src="js/calendar.js"></script>
</footer>

  

</body>
</html>
