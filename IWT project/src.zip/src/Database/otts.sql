-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 27, 2023 at 11:46 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `otts`
--
CREATE DATABASE  IF NOT EXISTS `OTTS` /*!40100 DEFAULT CHARACTER SET utf8mb3 */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `OTTS`;

-- --------------------------------------------------------

--
-- Table structure for table `card_details`
--

CREATE TABLE `card_details` (
  `type` varchar(255) NOT NULL,
  `cnumber` varchar(255) NOT NULL,
  `holdername` varchar(255) NOT NULL,
  `exp` varchar(255) NOT NULL,
  `cvv` int(3) NOT NULL,
  `amount` float NOT NULL,
  `email` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `card_details`
--

INSERT INTO `card_details` (`type`, `cnumber`, `holdername`, `exp`, `cvv`, `amount`, `email`) VALUES
('visa', '789456123', 'Nadil Senruka', '08-25', 456, 20000, 3),
('mastercard', '1234654664545', 'Liyanage N S', '12-26', 852, 30000, 5),
('mastercard', '1231212323', 'Nadil', '12-25', 336, 1000, 6);

-- --------------------------------------------------------

--
-- Table structure for table `contactus`
--

CREATE TABLE `contactus` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `message` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `contactus`
--

INSERT INTO `contactus` (`id`, `name`, `email`, `subject`, `message`) VALUES
(4, 'Nadil Senruka', 'it22144430@my.sliit.lk', 'SPM', 'abc 123');

-- --------------------------------------------------------

--
-- Table structure for table `exam`
--

CREATE TABLE `exam` (
  `id` int(11) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `subject` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `exam`
--

INSERT INTO `exam` (`id`, `date`, `time`, `subject`) VALUES
(8, '2023-06-14', '01:30:00', 'PCM'),
(9, '2023-06-15', '01:30:00', 'SE'),
(10, '2023-06-16', '01:00:00', 'TE'),
(11, '2023-06-17', '01:30:00', 'DI');

-- --------------------------------------------------------

--
-- Table structure for table `lecturer`
--

CREATE TABLE `lecturer` (
  `id` int(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `nic` varchar(12) NOT NULL,
  `module1` varchar(255) NOT NULL,
  `module2` varchar(255) NOT NULL,
  `module3` varchar(255) NOT NULL,
  `bank` varchar(255) NOT NULL,
  `account` varchar(255) NOT NULL,
  `accname` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `lecturer`
--

INSERT INTO `lecturer` (`id`, `first_name`, `last_name`, `email`, `password`, `nic`, `module1`, `module2`, `module3`, `bank`, `account`, `accname`) VALUES
(12, 'nadil', 'liyanage', 'it22144430@my.sliit.lk', '123@sliit', '20024598427', 'Strategies for Supporting Students with', 'Introduction to Differentiated Instruction', 'Not Selected', 'Bank of Ceylon (BOC)', '43753', 'nadil liyanage'),
(13, 'albert', 'einstein', 'albert@gmail.com', 'albert@321', '6975482513V', 'Disabilities', 'Understanding IEPs', 'Understanding IEPs', 'Bank of Ceylon (BOC)', '3555168435', 'albert einstein'),
(14, 'nadil', 'liyanage', 'nadilsenrukabk@gmail.com', '12345678', '200216601V', 'Introduction to Educational Technology', 'Digital Literacy and Citizenship', 'Not Selected', 'Hatton National Bank (HNB)', '122488', 'Liyanage N s');

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

CREATE TABLE `teacher` (
  `id` int(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `nic` varchar(12) NOT NULL,
  `course` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `teacher`
--

INSERT INTO `teacher` (`id`, `first_name`, `last_name`, `email`, `password`, `nic`, `course`) VALUES
(21, 'nadil', 'liyanage', 'it22144430@my.sliit.lk', 'Sliit@123', '200216601045', 'Technology in Education'),
(22, 'albert', 'einstein', 'albert@gmail.com', 'albert@123', '9648758754V', 'Technology in Education'),
(23, 'nadil', 'senruka', 'nadilsenrukabk@gmail.com', 'asdadqweq', '200216601045', 'Technology in Education');

-- --------------------------------------------------------

--
-- Table structure for table `timetable-crt`
--

CREATE TABLE `timetable-crt` (
  `id` int(11) NOT NULL,
  `module` varchar(255) NOT NULL,
  `duration` varchar(255) NOT NULL,
  `lecId` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `timetable-crt`
--

INSERT INTO `timetable-crt` (`id`, `module`, `duration`, `lecId`, `link`) VALUES
(4, 'Introduction to Culturally Responsive Teaching', '1 hour 50 min', 'TT5020', 'https://zoom.us'),
(8, 'Anti-Bias Education', '1 hour 30 min', 'TT1010', 'teams.us');

-- --------------------------------------------------------

--
-- Table structure for table `timetable-di`
--

CREATE TABLE `timetable-di` (
  `id` int(11) NOT NULL,
  `module` varchar(255) NOT NULL,
  `duration` varchar(255) NOT NULL,
  `lecId` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `timetable-di`
--

INSERT INTO `timetable-di` (`id`, `module`, `duration`, `lecId`, `link`) VALUES
(4, 'Introduction to Differentiated Instruction', '1 hour 50 min', 'TT4020', 'https://zoom.us'),
(5, 'Accommodations for Diverse Learners', '1 hour 50 min', 'TT4030', 'teams.us');

-- --------------------------------------------------------

--
-- Table structure for table `timetable-pcm`
--

CREATE TABLE `timetable-pcm` (
  `id` int(11) NOT NULL,
  `module` varchar(255) NOT NULL,
  `duration` varchar(255) NOT NULL,
  `lecId` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `timetable-pcm`
--

INSERT INTO `timetable-pcm` (`id`, `module`, `duration`, `lecId`, `link`) VALUES
(5, 'Introduction to Pedagogy', '1 hour 50 min', 'TT2020', 'teams.us'),
(6, 'Classroom Management Strategies', '1 hour 50 min', 'TT2030', 'zoom.us');

-- --------------------------------------------------------

--
-- Table structure for table `timetable-se`
--

CREATE TABLE `timetable-se` (
  `id` int(11) NOT NULL,
  `module` varchar(255) NOT NULL,
  `duration` varchar(255) NOT NULL,
  `lecId` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `timetable-se`
--

INSERT INTO `timetable-se` (`id`, `module`, `duration`, `lecId`, `link`) VALUES
(3, 'Strategies for Supporting Students with', '1 hour 50 min', 'TT4040', 'teams.us'),
(4, 'Laws and Regulations in Special Education', '1 hour 50 min', 'TT4020', 'zoom.us');

-- --------------------------------------------------------

--
-- Table structure for table `timetable-te`
--

CREATE TABLE `timetable-te` (
  `id` int(11) NOT NULL,
  `module` varchar(255) NOT NULL,
  `duration` varchar(255) NOT NULL,
  `lecId` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `timetable-te`
--

INSERT INTO `timetable-te` (`id`, `module`, `duration`, `lecId`, `link`) VALUES
(3, 'Instructional Technology in the Classroom', '1 hour 50 min', 'TT3040', 'https://zoom.us'),
(4, 'Instructional Technology in the Classroom', '1 hour 50 min', 'TT3040', 'zoom.us');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `card_details`
--
ALTER TABLE `card_details`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `contactus`
--
ALTER TABLE `contactus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `exam`
--
ALTER TABLE `exam`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lecturer`
--
ALTER TABLE `lecturer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `teacher`
--
ALTER TABLE `teacher`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `timetable-crt`
--
ALTER TABLE `timetable-crt`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `timetable-di`
--
ALTER TABLE `timetable-di`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `timetable-pcm`
--
ALTER TABLE `timetable-pcm`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `timetable-se`
--
ALTER TABLE `timetable-se`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `timetable-te`
--
ALTER TABLE `timetable-te`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `card_details`
--
ALTER TABLE `card_details`
  MODIFY `email` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `contactus`
--
ALTER TABLE `contactus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `exam`
--
ALTER TABLE `exam`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `lecturer`
--
ALTER TABLE `lecturer`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `teacher`
--
ALTER TABLE `teacher`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `timetable-crt`
--
ALTER TABLE `timetable-crt`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `timetable-di`
--
ALTER TABLE `timetable-di`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `timetable-pcm`
--
ALTER TABLE `timetable-pcm`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `timetable-se`
--
ALTER TABLE `timetable-se`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `timetable-te`
--
ALTER TABLE `timetable-te`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
