<?php 

	include_once'db_conn.php';

	error_reporting(0);
	session_start();

	if($_SERVER["REQUEST_METHOD"]=="POST")
	{
		$email = $_POST['email'];
		$password = $_POST['password'];
        $sql = "(SELECT email, password FROM lecturer WHERE email = '$email' AND password = '$password') UNION (SELECT email, password FROM teacher WHERE email = '$email' AND password = '$password')";
		

		$result=mysqli_query($conn,$sql);

		$row=mysqli_fetch_array($result);

		$total=mysqli_num_rows($result);

		if($total == 1)
		{
			$_SESSION['current_user']=$email;

			header("location:home.php");
		}
		else
		{
		
            header("location:login-index.php?msg=email or password do not match");
			    
		}
	}
?>
