<?php
include "db_conn.php";

if (isset($_POST["submit"])) {
  $type = $_POST['type'];
  $cnumber = $_POST['cnumber'];
  $holdername = $_POST['holdername'];
  $exp = $_POST['exp'];
  $cvv = $_POST['cvv'];
  $amount = $_POST['amount'];

   $sql = "INSERT INTO card_details (`type`, `cnumber`, `holdername`, `exp`, `cvv`, `amount`) VALUES ('$type', '$cnumber', '$holdername', '$exp', '$cvv', '$amount')";

   $result = mysqli_query($conn, $sql);

   if ($result) {
      header("Location: Home.php?msg=New record created successfully");
   } else {
      echo "Failed: " . mysqli_error($conn);
   }
}
?>
