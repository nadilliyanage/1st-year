<?php
include "db_conn.php";
?>

<!DOCTYPE html>
<html>
<head>
  <title>Teacher Trainer System</title>
   <link rel="stylesheet" type="text/css" href="styles/style.css">
    <link rel="stylesheet" type="text/css" href="styles/Home.css">
    

</head>
<body>
  <div class="container">
    <header>
  <div class="logo">
    <img src="images/logo.png" alt="" height="40" width="130">
  </div>
  <nav>
    <ul>
      <li><a href="Home.php">Home</a></li>
      <li><a href="course.html">My Course</a></li>
      <li><a href="add-contactus.php">Contact US</a></li>
      <li><a href="Help & support.html">Help & Support</a></li>
      <li><a href="profile.php"><img src="images/profile.png" class="prof" height="40" width="40"></a></li>
    </ul>
  </nav>
</header>
<div class="container">




<hr style="color:white;">
    <div class="content">
      <div class="left-section">
        
        <h2>EduTeach Notifications</h2>
		
		<div class="notice">
		<h3>Notice 1</h3>
		<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer aliquam sed urna vitae tempor. Fusce quis finibus ex.</p>
	  </div>
	  <div class="notice">
		<h3>Notice 2</h3>
		<p>Etiam nec lectus non lorem eleifend euismod id sit amet lectus. Sed ut odio eleifend, cursus nunc nec, ullamcorper elit.</p>
	  </div>
	  <div class="notice">
		<h3>Notice 3</h3>
		<p>Nullam feugiat tincidunt eleifend. Curabitur ut iaculis enim. Integer fringilla tincidunt felis eget gravida.</p>
	  </div>
      </div>
      <div class="middle-section">
         <div class="home-content">
          <h2>Welcome to EduTeach!</h2>
          <p>Thank you for joining the Teacher Trainer System.</p>
          <p>As a member, you have access to a wide range of resources and tools to support your professional development and enhance your teaching skills.</p>
          <p>Explore the system to find:</p>
          <ul>
            <li>Lesson planning and curriculum development tools</li>
            <li>Interactive teaching materials and resources</li>
            <li>Assessment and feedback mechanisms</li>
            <li>Professional development courses and workshops</li>
          </ul>
          <div class="cta-section">
            <h3>Get Started</h3>
            <p>Start utilizing the system to its fullest potential and take your teaching to the next level.</p><br>
            <a href="course.html"><button>MY COURSE</button></a><br><br>
            <a href="paymentpage.php"><button>Payment</button></a>
            <a href="logout.php"><button>Logout</button></a>
          </div>
        </div>
      </div>
      <div class="right-section">
       
        <h2>Examination Notice</h2>
        <div class="mini-timetable">
          <h3>Upcoming Exam:</h3>
          <table class="table-viwe">
            <thead class="table-dark">
              <tr>
                
                <th scope="col">Date</th>
                <th scope="col">Time</th>
                <th scope="col">Module</th>
                <th scope="col">Action</th>
              </tr>
            </thead>
            <tbody>
              <?php
              $sql = "SELECT * FROM `exam`";
              $result = mysqli_query($conn, $sql);
              while ($row = mysqli_fetch_assoc($result)) {
              ?>
                <tr>
                  
                  <td><?php echo $row["date"] ?></td>
                  <td><?php echo $row["time"] ?></td>
                  <td><?php echo $row["subject"] ?></td>
                  <td>
                    <a href="edit-exam.php?id=<?php echo $row["id"] ?>" class="edit-button">Update </a><br>
                    <a href="delete-exam.php?id=<?php echo $row["id"] ?>" class="delete-button">Delete </a>
                  </td>
                </tr>
              <?php
              }
              ?>
            </tbody>
          </table>
          <br><br>
          <a href="add-exam.php" class="add-new">Add New</a>
        </div>
      </div>
    </div>
    <footer class="footer-section">
	<hr style="color:white;">
	<div class="sup_img">
	  <img src="images/support.png" alt="" height="150" width="200"><br>
      <h3>DO YOU NEED ANY</h3>
	  <h1>SUPPORT?</h1>
	</div>

  <div class="footer-cta pt-5 pb-5">
    <div class="single-cta">
      <div class="cta-text">
        <img src="images/location.png" alt="" height="35" width="35">
        <h4>Find us</h4>
        <span>105, New Kandy RD, Malabe</span>
      </div>
	  
	  <div class="calendar"></div>

	  
    </div>
    <div class="single-cta">
      <div class="cta-text">
        <img src="images/Phone.png" alt="" height="35" width="35">
        <h4>Call us</h4>
        <span>+94 71 234 5678</span>
      </div>
    </div>
    <div class="single-cta">
      <div class="cta-text">
        <img src="images/mail.png" alt="" height="35" width="35">
        <h4>Mail us</h4>
        <span>info@eduteach.com</span>
      </div>
	  <div class="download">
	    <p><b>Get us on</b></p>
	    <img src="images/playstore.png" alt="" height="40" width="80">
        <img src="images/appstore.png" alt="" height="40" width="80">
        <img src="images/winstore.png" alt="" height="40" width="80">
	  </div>
    </div>
  </div>
  <div class="social_logo">
    <a href="https://support.google.com/accounts/answer/27441?hl=en"><img src="images/google.png" alt="" height="20" width="20"></a>
    <a href="https://www.linkedin.com/signup"><img src="images/linkedin.png" alt="" height="20" width="20"></a>
    <a href="https://twitter.com/i/flow/signup"><img src="images/twitter.png" alt="" height="20" width="20"></a>
    <a href="https://www.facebook.com/signup"><img src="images/fb.png" alt="" height="20" width="20"></a>
    <a href="https://web.telegram.org/"><img src="images/telegram.png" alt="" height="20" width="20"></a>
    <a href="https://github.com/signup"><img src="images/github.png" alt="" height="20" width="20"></a>
  </div>
  
<div class="copyright">
  <p>Visit Our Page : <a href="Login-index.php">https://www.eduteach.com</a></p>
  
</div>
  <h6>Created By MLB_11.1_09<h6>
  <script src="js/calendar.js"></script>
</footer>
  </div>
</body>
</html>
